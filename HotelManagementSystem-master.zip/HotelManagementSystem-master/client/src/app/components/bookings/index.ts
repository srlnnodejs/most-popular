export { BookingsModule } from './bookings.module';
