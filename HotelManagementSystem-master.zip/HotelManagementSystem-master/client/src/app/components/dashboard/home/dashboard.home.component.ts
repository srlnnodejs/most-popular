import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'list-dashboard',
    templateUrl: './dashboard.home.component.html',
    encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {
    constructor() { }
    ngOnInit() { }
}
