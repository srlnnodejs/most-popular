export { RoomsModule } from './rooms.module';
