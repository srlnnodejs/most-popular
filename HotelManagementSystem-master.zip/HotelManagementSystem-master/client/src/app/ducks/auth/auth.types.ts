export const types = {
    // auth.controller - login
    LOGIN_REQUEST: 'LOGIN/REQUEST',
    LOGIN_SUCCESS: 'LOGIN/SUCCESS',
    LOGIN_FAILURE: 'LOGIN/FAILURE',
};
