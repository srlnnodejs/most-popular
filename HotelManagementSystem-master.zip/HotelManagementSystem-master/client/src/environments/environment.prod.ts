export const environment = {
    production: true,
    name: 'Ruals',
    api_url: 'http://api.hms.com'
};
