import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maintanace-sidebar',
  templateUrl: './maintanace-sidebar.component.html',
  styleUrls: ['./maintanace-sidebar.component.css']
})
export class MaintanaceSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
