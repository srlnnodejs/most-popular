import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-res-side-bar',
  templateUrl: './res-side-bar.component.html',
  styleUrls: ['./res-side-bar.component.css']
})
export class ResSideBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
