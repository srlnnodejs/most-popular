import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accounts-sidebar',
  templateUrl: './accounts-sidebar.component.html',
  styleUrls: ['./accounts-sidebar.component.css']
})
export class AccountsSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
