import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventroy-side-bar',
  templateUrl: './inventroy-side-bar.component.html',
  styleUrls: ['./inventroy-side-bar.component.css']
})
export class InventroySideBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
