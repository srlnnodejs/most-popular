import { NewCustomer } from './new-customer';

describe('NewCustomer', () => {
  it('should create an instance', () => {
    expect(new NewCustomer()).toBeTruthy();
  });
});
