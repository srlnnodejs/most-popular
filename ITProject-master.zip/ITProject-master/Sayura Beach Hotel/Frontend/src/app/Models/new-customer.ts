export class NewCustomer {
        constructor(
          public id: any,
          public name: string,
          public address: string,
          public NIC: string,
          public telephone: string,
          public email: string
        ) {  }
}
