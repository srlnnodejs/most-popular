function validateEmpFDelete(){
    var FempId = document.getElementById('eid');
    
	
		
		if(FempId.value == '')
		{
			alert('Please enter employee ID');
			return false;
		}
		
		
	
}