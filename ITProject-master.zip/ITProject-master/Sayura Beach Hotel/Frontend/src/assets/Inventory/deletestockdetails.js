function deletestockdetails(){

    var NIC = document.getElementById('nic');

		if(NIC.value == '')
		{
			alert('Please enter NIC');
			return false;
        }
    }